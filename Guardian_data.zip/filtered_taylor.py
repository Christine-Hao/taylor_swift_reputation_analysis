import csv

def filter_articles_by_keyword(csv_filename, keyword):
    filtered_articles = []

    with open(csv_filename, 'r', encoding='utf-8') as csv_file:
        reader = csv.reader(csv_file)
        next(reader)

        for row in reader:
            title, standfirst = row
            if keyword.lower() in title.lower() or keyword.lower() in standfirst.lower():
                filtered_articles.append((title, standfirst))

    return filtered_articles

csv_filename = 'one_and_half_months.csv'
keyword = 'Taylor Swift'

taylor_swift_articles = filter_articles_by_keyword(csv_filename, keyword)

output_csv_filename = 'filtered_taylor_swift_articles.csv'

with open(output_csv_filename, 'w', newline='', encoding='utf-8') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow(['Title', 'Standfirst'])
    writer.writerows(taylor_swift_articles)

for article in taylor_swift_articles:
    print(f"Title: {article[0]}, Standfirst: {article[1]}")
    print("----------------------------------------------------")
    
output_txt_filename = 'filtered_taylor_swift_articles_taylor_swift_articles.txt'

with open(output_txt_filename, 'w', encoding='utf-8') as txt_file:
    for article in taylor_swift_articles:
        txt_file.write(f"Title: {article[0]},\nStandfirst: {article[1]}\n")
        txt_file.write("----------------------------------------------------\n")

output_txt_filename

