import pandas as pd

# 定义要合并的TSV文件列表
tsv_files = ['1.tsv', '2.tsv', '3.tsv', '4.tsv', '5.tsv',
             '6.tsv', '7.tsv', '8.tsv', '9.tsv']

# 首先读取第一个TSV文件并初始化标题集合
df_merged = pd.read_csv(tsv_files[0], sep='\t', encoding='utf-8')
titles = set(df_merged['Title'])  # 假设标题列名为"Title"

# 遍历剩余的TSV文件
for tsv_file in tsv_files[1:]:
    # 读取TSV文件
    df = pd.read_csv(tsv_file, sep='\t', encoding='utf-8')
    # 通过标题过滤出新的行
    new_rows = df[~df['Title'].isin(titles)]
    # 更新标题集合
    titles.update(new_rows['Title'])
    # 将新行添加到合并后的DataFrame
    df_merged = pd.concat([df_merged, new_rows], ignore_index=True)

# 保存合并后的DataFrame为新的TSV文件
df_merged.to_csv('merged.tsv', sep='\t', encoding='utf-8', index=False)
