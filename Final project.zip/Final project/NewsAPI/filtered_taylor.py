# Revised script to filter articles based on the given TSV format.

import csv

def filter_articles_by_keyword(tsv_filename, keyword, output_tsv_filename):
    filtered_articles = []

    with open(tsv_filename, 'r', encoding='utf-8') as tsv_file:
        # Create a csv.DictReader, assuming the first line of the TSV file contains headers
        reader = csv.DictReader(tsv_file, delimiter='\t')

        # Filter articles containing the keyword in the title or description, case insensitive
        for row in reader:
            if keyword.lower() in row['Title'].lower() or keyword.lower() in row['Description'].lower():
                filtered_articles.append(row)

    # Write the filtered articles to a new TSV file
    with open(output_tsv_filename, 'w', newline='', encoding='utf-8') as out_tsv_file:
        writer = csv.DictWriter(out_tsv_file, fieldnames=reader.fieldnames, delimiter='\t')
        writer.writeheader()
        writer.writerows(filtered_articles)

# Define the path to the TSV file and the output file name
tsv_filename = 'NewAPI_merged.tsv'
output_tsv_filename = 'filtered_taylor_swift_articles.tsv'
keyword = 'Taylor Swift'

# Filter the articles and write to a new TSV file
filter_articles_by_keyword(tsv_filename, keyword, output_tsv_filename)

# Return the path to the new filtered TSV file
output_tsv_filename
