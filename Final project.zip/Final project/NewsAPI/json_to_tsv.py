import json
import pandas as pd
import csv

def clean_newlines(text):
    return text.replace('\n', ' ').replace('\r', ' ') if text else text

def extract_data_to_tsv(json_file, tsv_file):
    with open(json_file, 'r') as file:
        data = json.load(file)

    # 提取所需字段并清理换行符
    extracted_data = [(clean_newlines(article["title"]), 
                       clean_newlines(article["description"]), 
                       clean_newlines(article["publishedAt"])) 
                      for article in data["articles"]]

    # 转换为DataFrame
    df = pd.DataFrame(extracted_data, columns=["Title", "Description", "Published At"])

    # 假设 df 是您的 DataFrame
    df.to_csv(tsv_file, sep='\t', encoding='utf-8-sig', index=False)

# 使用示例
json_file = 'tswift_articles_5.json'  # 替换为您的JSON文件名
tsv_file = '5.tsv'  # 输出的TSV文件名
extract_data_to_tsv(json_file, tsv_file)
