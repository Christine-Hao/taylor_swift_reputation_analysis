import csv
import requests
from datetime import datetime, timedelta

def download_articles_gnews(api_key, keyword, output_file, start_date, end_date, max_pages):
    base_url = "https://gnews.io/api/v4/search"
    all_articles = []
    seen_titles = set()  # Set to keep track of titles we've already seen

    for page in range(1, max_pages + 1):
        params = {
            "q": keyword,
            "token": api_key,
            "lang": "en",
            "max": 10,  # Assuming 10 articles per page
            "from": start_date,
            "to": end_date,
            "page": page
        }

        response = requests.get(base_url, params=params)
        if response.status_code != 200:
            break  # Exit if the request fails

        data = response.json()
        articles = data.get('articles', [])

        for article in articles:
            title = article['title']
            if title in seen_titles:
                continue

            description = article['description']
            published_at = article['publishedAt']
            all_articles.append([title, description, published_at])
            seen_titles.add(title)

    # Write to TSV file
    with open(output_file, 'w', newline='', encoding='utf-8') as tsv_file:
        writer = csv.writer(tsv_file, delimiter='\t')
        writer.writerow(['Title', 'Description', 'Published At'])
        writer.writerows(all_articles)

# Set your GNews API key, keyword, start date, end date, maximum pages, and output file name
api_key = "cad99aa45317a195e1dfe4538ef65f86"  # Replace with your actual GNews API key
keyword = "Taylor Swift"
start_date = (datetime.now() - timedelta(days=45)).strftime('%Y-%m-%d')  # 30 days ago
end_date = datetime.now().strftime('%Y-%m-%d')  # Today
max_pages = 50  # Maximum number of pages to fetch
output_file = "taylor_swift_news.tsv"

# Call the function to download articles and save to a TSV file
download_articles_gnews(api_key, keyword, output_file, start_date, end_date, max_pages)
