import requests  # 导入requests库用于HTTP请求
import pandas as pd  # 导入pandas库用于数据处理
from datetime import datetime, timedelta  # 导入datetime和timedelta用于日期处理

# 初始化变量
base_url = "https://gnews.io/api/v4/search"  # GNews API的基础URL
api_key = "cad99aa45317a195e1dfe4538ef65f86"  # 你的GNews API密钥，请替换为你自己的
start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')  # 设置开始日期为30天前
end_date = datetime.now().strftime('%Y-%m-%d')  # 设置结束日期为今天
news_data = []  # 初始化用于存储新闻数据的列表

# 循环获取每页数据
page = 1  # 开始时页码为1
while True:  # 开始一个无限循环
    params = {  # 定义请求参数
        "q": "Taylor Swift",  # 查询关键字为“Taylor Swift”
        "country": ["US", "CA"],  # 限制新闻来源国家为美国和加拿大
        "token": api_key,  # API密钥
        "lang": "en",  # 限制新闻语言为英语
        "max": 10,  # 每次请求最多返回10篇文章
        "from": start_date,  # 设定新闻的开始时间
        "to": end_date,  # 设定新闻的结束时间
        "page": page  # 设置当前页码
    }

    response = requests.get(base_url, params=params)  # 发送HTTP GET请求
    if response.status_code != 200:  # 如果响应的状态码不是200（请求成功）
        break  # 退出循环

    articles = response.json().get("articles", [])  # 解析响应的JSON数据中的文章部分
    if not articles:  # 如果文章列表为空
        break  # 退出循环

    # 筛选包含“Taylor Swift”的新闻
    for article in articles:  # 遍历所有文章
        if "Taylor Swift" in article["title"] or "Taylor Swift" in article["description"]:  # 如果标题或描述中包含“Taylor Swift”
            news_data.append(article)  # 将文章添加到新闻数据列表中

    page += 1  # 页码加1，以获取下一页数据

# 保存数据到CSV文件
df = pd.DataFrame(news_data)  # 将新闻数据转换为pandas DataFrame
df.to_csv("taylor_swift_news.csv", index=False)  # 将DataFrame保存为CSV文件，不包含索引列
