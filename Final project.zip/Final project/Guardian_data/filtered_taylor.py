import csv

def filter_articles_by_keyword(csv_filename, keyword):
    filtered_articles = []

    with open(csv_filename, 'r', encoding='utf-8') as csv_file:
        reader = csv.DictReader(csv_file)  # 使用DictReader来方便地按列名访问每行数据

        for row in reader:
            title = row['Title']
            standfirst = row['Standfirst']
            publication_date = row['Publication Date']
            if keyword.lower() in title.lower() or keyword.lower() in standfirst.lower():
                filtered_articles.append((title, standfirst, publication_date))

    return filtered_articles

csv_filename = 'articles_20231204183529.csv'
keyword = 'Taylor Swift'

taylor_swift_articles = filter_articles_by_keyword(csv_filename, keyword)

output_tsv_filename = 'filtered_taylor_swift_articles1.tsv'  # 修改文件扩展名为.tsv

with open(output_tsv_filename, 'w', newline='', encoding='utf-8') as tsv_file:
    writer = csv.writer(tsv_file, delimiter='\t')  # 指定分隔符为制表符
    writer.writerow(['Title', 'Standfirst', 'Publication Date'])  # 保持与输入文件相同的列名
    writer.writerows(taylor_swift_articles)

for article in taylor_swift_articles:
    print(f"Title: {article[0]}, Standfirst: {article[1]}, Publication Date: {article[2]}")
    print("----------------------------------------------------")

# 以下输出到文本文件的代码段可以保持不变，因为它不依赖于CSV文件的格式
output_txt_filename = 'filtered_taylor_swift_articles1.txt'

with open(output_txt_filename, 'w', encoding='utf-8') as txt_file:
    for article in taylor_swift_articles:
        txt_file.write(f"Title: {article[0]},\nStandfirst: {article[1]},\nPublication Date: {article[2]}\n")
        txt_file.write("----------------------------------------------------\n")

print(f"Filtered articles have been saved to {output_tsv_filename} and {output_txt_filename}")
